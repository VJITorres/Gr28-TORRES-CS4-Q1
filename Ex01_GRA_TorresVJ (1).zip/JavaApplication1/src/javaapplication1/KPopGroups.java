/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author GRAVITON
 */
public class KPopGroups {
        public static void main(String[] args) {
        // Group 1
        String group1Name = "NovaSol";
        int group1Members = 7;
        double group1AverageHeight = 1.64;

        // Group 2
        String group2Name = "Stella";
        int group2Members = 4;
        double group2AverageHeight = 1.62;

        // Group 3
        String group3Name = "WhiMe";
        int group3Members = 5;
        double group3AverageHeight = 1.67;

        // Display group 1 information
        System.out.println("Fictional K-Pop Group 1");
        System.out.println("Group Name: " + group1Name);
        System.out.println("Number of Members: " + group1Members);
        System.out.println("Average Height of Members in Meters: " + group1AverageHeight);
        System.out.println();

        // Display group 2 information
        System.out.println("Fictional K-Pop Group 2");
        System.out.println("Group Name: " + group2Name);
        System.out.println("Number of Members: " + group2Members);
        System.out.println("Average Height of Members in Meters: " + group2AverageHeight);
        System.out.println();

        // Display group 3 information
        System.out.println("Fictional K-Pop Group 3");
        System.out.println("Group Name: " + group3Name);
        System.out.println("Number of Members: " + group3Members);
        System.out.println("Average Height of Members in Meters: " + group3AverageHeight);
        System.out.println();

        // Calculate total number of members
        int totalMembers = group1Members + group2Members + group3Members;
        System.out.println("Total Number of members of the 3 mentioned K-Pop Groups: " + totalMembers);

        // Check if WhiMe has more than 6 members
        boolean isWhiMeMoreThan6Members = group3Members > 6;
        System.out.println("WhiMe has more than 6 members (true/false): " + isWhiMeMoreThan6Members);

        // Compare average heights of NovaSol and Stella
        boolean isNovaSolTallerThanStella = group1AverageHeight > group2AverageHeight;
        System.out.println("On average, NovaSol members are taller than Stella members (true/false): " + isNovaSolTallerThanStella);
    }
}
