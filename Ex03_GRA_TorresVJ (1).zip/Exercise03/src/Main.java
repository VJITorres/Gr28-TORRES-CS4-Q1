//Ex03_GRA_TorresVJ

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        Song song1 = new Song("Night Aviation (Interpretaion of Dreams)", "GWSN");
        Song song2 = new Song("Tweaks ~ Heavy Cloud but no Rain", "GWSN");
        Song song3 = new Song("GingaMingaYo", "Billlie");

        Singer singer1 = new Singer("GWSN");
        Singer singer2 = new Singer("Billlie"); 

        
        singer1.changeFavSong(song1);
        singer2.changeFavSong(song3); 

        displaySingerInfo(singer1);
        displaySingerInfo(singer2); 

        int audienceSize = 12;
        singer1.performForAudience(audienceSize);

        System.out.println("----------------------------------------------------");
        System.out.println(singer1.getName() + " performs once (1) in front of " + audienceSize + " people");
        System.out.println("----------------------------------------------------");

        double earnings = audienceSize * 100;
        singer1.setEarnings(earnings);

        System.out.println(singer1.getName() + " made $" + earnings + " after performing in front of " + audienceSize + " people");
        System.out.println("----------------------------------------------------");

        singer1.changeFavSong(song2);

        System.out.println(singer1.getName() + " changed their favorite song to " + singer1.getFavoriteSong().getTitle());
        System.out.println("----------------------------------------------------");

        int numberOfWins = Wins.calculateWins(audienceSize);
        System.out.println(singer1.getName() + " won " + numberOfWins + " trophies in Korean music shows!");
        System.out.println("----------------------------------------------------");

        int collabAudienceSize = 20;
        double totalCollabProfit = collabAudienceSize * 100; 
        double collabProfitPerSinger = totalCollabProfit / 2; 

        singer1.performForAudience(collabAudienceSize, singer2);
        singer1.setEarnings(singer1.getEarnings() + collabProfitPerSinger); 
        singer2.setEarnings(collabProfitPerSinger); 

        System.out.println(singer1.getName() + " and " + singer2.getName() + " made a collab, performing in front of " + collabAudienceSize + " people");
        System.out.println("----------------------------------------------------");
        System.out.println("They split the profit, each of them getting $" + collabProfitPerSinger);
        System.out.println("----------------------------------------------------");
        System.out.println("A generous K-Pop producer gave GWSN $500 for their next performance");
        System.out.println("----------------------------------------------------");

        displaySingerInfo(singer1);
        displaySingerInfo(singer2); 
    }

    private static void displaySingerInfo(Singer singer) {
        System.out.println("----------------------------------------------------");
        System.out.println("Artist: " + singer.getName());
        System.out.println("Number of Performances: " + singer.gettotalPerformances());
        System.out.println("Earnings: $" + singer.getEarnings());
        System.out.println("Favorite Song: " + singer.getFavoriteSong().getTitle());
        System.out.println("----------------------------------------------------");
    }
}







