/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Singer {
    private String name;
    private int totalPerformances;
    private double earnings;
    private Song favoriteSong;

    public Singer(String name) {
        this.name = name;
        this.totalPerformances = 0;
        this.earnings = 0.0;
        this.favoriteSong = new Song("Default Song", "Unknown Artist"); // Set a default favorite song
    }

    public void performForAudience(int audienceSize) {
        this.totalPerformances++;
        this.earnings += audienceSize * 100;
    }
    
    // Overloaded performForAudience method to allow singers to perform together
    public void performForAudience(int audienceSize, Singer otherSinger) {
        int totalAudienceSize = audienceSize + (audienceSize / 2); // Split the audience
        double profitPerSinger = totalAudienceSize * 100 / 2; // Split the profit
        this.totalPerformances++;
        this.earnings += profitPerSinger;
        otherSinger.totalPerformances++;
        otherSinger.earnings += profitPerSinger;
    }

    public void changeFavSong(Song newFavoriteSong) {
        this.favoriteSong = newFavoriteSong;
    }

    public String getName() {
        return name;
    }

    public int gettotalPerformances() {
        return totalPerformances;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public Song getFavoriteSong() {
        return favoriteSong;
    }
}



