/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
import java.util.ArrayList;

public class Store {
    private String name;
    private double earnings;
    private ArrayList<Item> itemList;
    private static ArrayList<Store> storeList = new ArrayList<>();

    public Store(String name) {
        this.name = name;
        this.earnings = 0;
        this.itemList = new ArrayList<>();
        storeList.add(this);
    }

    public String getName() {
        return name;
    }

    public double getEarnings() {
        return earnings;
    }

    public void sellItem(int index) {
        if (index >= 0 && index < itemList.size()) {
            Item soldItem = itemList.get(index);
            earnings += soldItem.getCost();
            System.out.println(getName() + " Sold: " + soldItem.getName() + ", Price: " + soldItem.getCost());
        } else {
            System.out.println(getName() + " Invalid index. There are only " + this.itemList.size() + " items in the store.");
        }
    }

    public void sellItem(String name) {
        Item itemToRemove = null;
        for (Item item : itemList) {
            if (item.getName().equals(name)) {
                itemToRemove = item;
                break;
            }
        }

        if (itemToRemove != null) {
            itemList.remove(itemToRemove);
            earnings += itemToRemove.getCost();
            System.out.println(getName() + " Sold: " + itemToRemove.getName() + ", Price: " + itemToRemove.getCost());
        } else {
            System.out.println(getName() + " doesn't sell " + name);
        }
    }

    public void sellItem(Item i) {
        if (itemList.contains(i)) {
            itemList.remove(i);
            earnings += i.getCost();
            System.out.println(getName() + " Sold: " + i.getName() + ", Price: " + i.getCost());
        } else {
            System.out.println(getName() + " doesn't sell " + i.getName());
        }
    }

    public void addItem(Item i) {
        itemList.add(i);
    }

    public void filterType(String type) {
        System.out.println(getName() + " " + type + " Items:");
        boolean found = false;
        for (Item item : itemList) {
            if (item.getType().equalsIgnoreCase(type)) {
                System.out.println(item.getName());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No " + type.toLowerCase() + " items found.");
        }
        System.out.println();
    }

    public void filterCheap(double maxCost) {
        System.out.println(getName() + " Items cheaper than " + maxCost + ":");
        boolean found = false;
        for (Item item : itemList) {
            if (item.getCost() < maxCost) {
                System.out.println(item.getName());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No items cheaper than " + maxCost + " found.");
        }
        System.out.println();
    }

    public void filterExpensive(double minCost) {
        System.out.println(getName() + " Items more expensive than " + minCost + ":");
        boolean found = false;
        for (Item item : itemList) {
            if (item.getCost() > minCost) {
                System.out.println(item.getName());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No items more expensive than " + minCost + " found.");
        }
        System.out.println();
    }

    public static void printStats() {
        for (Store store : storeList) {
            System.out.println("Store Name: " + store.getName() + ", Earnings: " + store.getEarnings());
        }
    }
}






