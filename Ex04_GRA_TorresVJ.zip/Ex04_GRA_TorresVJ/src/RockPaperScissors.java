//Ex04_GRA_TorresVJ

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
import java.util.Scanner;

public class RockPaperScissors {
    private static int roundsToWin = 2; // Default rounds to win

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int playerScore = 0;
        int computerScore = 0;

        System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option:");
        while (true) {
            System.out.println("1. Start game");
            System.out.println("2. Change number of rounds to win (Default: 2)");
            System.out.println("3. Exit application");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    playGame(scanner, playerScore, computerScore);
                    break;
                case 2:
                    System.out.print("How many wins are needed to win a match? ");
                    roundsToWin = scanner.nextInt();
                    System.out.println("New setting has been saved!");
                    break;
                case 3:
                    System.out.println("Thank you for playing!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    private static void playGame(Scanner scanner, int playerScore, int computerScore) {
        System.out.println("This match will be first to " + roundsToWin + " wins.");

        while (true) {
            int computerMove = (int) Math.floor(Math.random() * 3) + 1;
            System.out.println("The computer has selected its move. Select your move:");
            System.out.println("1. Rock");
            System.out.println("2. Paper");
            System.out.println("3. Scissors");
            int playerMove = scanner.nextInt();

            if (playerMove < 1 || playerMove > 3) {
                System.out.println("Invalid move. Please choose a valid move.");
                continue;
            }

            String result = getRoundResult(playerMove, computerMove);
            System.out.println(result);

            if (result.contains("Player wins")) {
                playerScore++;
            } else if (result.contains("Computer wins")) {
                computerScore++;
            }

            System.out.println("Player: " + playerScore + " - Computer: " + computerScore);

            if (playerScore == roundsToWin) {
                System.out.println("Player wins!");
                break;
            } else if (computerScore == roundsToWin) {
                System.out.println("Computer wins!");
                break;
            }
        }
    }

    private static String getRoundResult(int playerMove, int computerMove) {
        String[] moves = {"Rock", "Paper", "Scissors"};
        String playerChoice = moves[playerMove - 1];
        String computerChoice = moves[computerMove - 1];

        if (playerMove == computerMove) {
            return "Round is tied!";
        } else if ((playerMove == 1 && computerMove == 3) || (playerMove == 2 && computerMove == 1) || (playerMove == 3 && computerMove == 2)) {
            return "Player chose " + playerChoice + ". Computer chose " + computerChoice + ". Player wins round!";
        } else {
            return "Player chose " + playerChoice + ". Computer chose " + computerChoice + ". Computer wins round!";
        }
    }
}

