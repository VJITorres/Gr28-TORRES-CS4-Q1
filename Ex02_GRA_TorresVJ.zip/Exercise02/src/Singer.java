/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Singer {
    private String name;
    private int noOfPerformances;
    private double earnings;
    private Song favoriteSong;

    public Singer(String name) {
        this.name = name;
        this.noOfPerformances = 0;
        this.earnings = 0.0;
    }

    public void performForAudience(int audienceSize) {
        this.noOfPerformances++;
        this.earnings += audienceSize * 100;
    }

    public void changeFavSong(Song newFavoriteSong) {
        this.favoriteSong = newFavoriteSong;
    }

    public String getName() {
        return name;
    }

    public int getNoOfPerformances() {
        return noOfPerformances;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }
    
    public Song getFavoriteSong() {
        return favoriteSong;
    }

}

