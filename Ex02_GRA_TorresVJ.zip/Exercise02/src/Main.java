/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Main {
    public static void main(String[] args) {
        Song song1 = new Song("Night Aviation (Interpretaion of Dreams)", "GWSN");
        Song song2 = new Song("Tweaks ~ Heavy Cloud but no Rain", "GWSN");

        Singer singer = new Singer("GWSN");

        // Assign a favorite song to the Singer
        singer.changeFavSong(song1);

        displaySingerInfo(singer);

        int audienceSize = 12;
        singer.performForAudience(audienceSize);

        System.out.println("----------------------------------------------------");
        System.out.println(singer.getName() + " performs once (1) in front of " + audienceSize + " people");
        System.out.println("----------------------------------------------------");

        double earnings = audienceSize * 100;
        singer.setEarnings(earnings);

        System.out.println(singer.getName() + " made $" + earnings + " after performing in front of " + audienceSize + " people");
        System.out.println("----------------------------------------------------");

        singer.changeFavSong(song2);
        
        System.out.println(singer.getName() + " changed their favorite song to " + singer.getFavoriteSong().getTitle());
        System.out.println("----------------------------------------------------");

        // Calculate the number of wins using the Wins class (This is my 4th file.)
        int numberOfWins = Wins.calculateWins(audienceSize);
        System.out.println(singer.getName() + " won " + numberOfWins + " trophies in Korean music shows!");
        System.out.println("----------------------------------------------------");
        displaySingerInfo(singer);
    }

    private static void displaySingerInfo(Singer singer) {
        System.out.println("----------------------------------------------------");
        System.out.println("Artist: " + singer.getName());
        System.out.println("Number of Performances: " + singer.getNoOfPerformances());
        System.out.println("Earnings: $" + singer.getEarnings());
        System.out.println("Favorite Song: " + singer.getFavoriteSong().getTitle());
        System.out.println("----------------------------------------------------");
    }
}





