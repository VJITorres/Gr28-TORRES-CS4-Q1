/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author user
 */
public class Wins {
    public static int calculateWins(int audienceSize) {
        // Calculate the number of wins based on the audience size (1 win for every 4 people)
        return audienceSize / 4;
    }
}

